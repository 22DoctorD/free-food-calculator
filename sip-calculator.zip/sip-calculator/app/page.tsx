'use client';
import { useState } from "react";

export default function SIPPayoutCalculator() {
  const [monthlyExpense, setMonthlyExpense] = useState(10000);
  const [sipPercent, setSipPercent] = useState(20);
  const [returnRate, setReturnRate] = useState(9);
  const [stepUpRate, setStepUpRate] = useState(2);
  const [inflationRate, setInflationRate] = useState(2);
  const [result, setResult] = useState(null);

  const calculate = () => {
    const x = monthlyExpense;
    const y0 = (sipPercent / 100) * x;
    const r = returnRate / 100 / 12;
    const inf = inflationRate / 100;

    let corpusNeeded = 0;
    let sipFV = 0;
    let year = 0;

    while (year < 100) {
      const futureX = x * Math.pow(1 + inf, year);
      corpusNeeded = futureX / r;

      sipFV = 0;
      for (let k = 0; k < year; k++) {
        const yk = y0 * Math.pow(1 + stepUpRate / 100, k);
        const months = (year - k) * 12;
        sipFV += yk * ((Math.pow(1 + r, months) - 1) / r);
      }

      if (sipFV >= corpusNeeded) break;
      year++;
    }

    setResult({ year, corpusNeeded: corpusNeeded.toFixed(0), sipFV: sipFV.toFixed(0) });
  };

  return (
    <div style={{ maxWidth: 600, margin: 'auto', padding: 20 }}>
      <h1>Lifetime SIP Payout Calculator</h1>
      <input type="number" value={monthlyExpense} onChange={(e) => setMonthlyExpense(Number(e.target.value))} placeholder="Monthly Expense (x)" /><br />
      <input type="number" value={sipPercent} onChange={(e) => setSipPercent(Number(e.target.value))} placeholder="SIP % of x" /><br />
      <input type="number" value={returnRate} onChange={(e) => setReturnRate(Number(e.target.value))} placeholder="Return Rate (%)" /><br />
      <input type="number" value={stepUpRate} onChange={(e) => setStepUpRate(Number(e.target.value))} placeholder="Step-up Rate (%)" /><br />
      <input type="number" value={inflationRate} onChange={(e) => setInflationRate(Number(e.target.value))} placeholder="Inflation Rate (%)" /><br />
      <button onClick={calculate}>Calculate</button>
      {result && (
        <div>
          <p>Years needed to invest: <strong>{result.year}</strong></p>
          <p>Required Corpus: ₹<strong>{result.corpusNeeded}</strong></p>
          <p>Future Value of SIP: ₹<strong>{result.sipFV}</strong></p>
        </div>
      )}
    </div>
  );
}